(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* scroll reveal */
  var els = document.querySelectorAll('.tc-reveal');
  var i;
  if (els.length) {
    if (!('IntersectionObserver' in window) || reduce) {
      for (i = 0; i < els.length; i++) { els[i].classList.add('in'); }
    } else {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
        });
      }, { threshold: 0.12 });
      for (i = 0; i < els.length; i++) { io.observe(els[i]); }
    }
  }

  /* compact sticky header after scrolling */
  var onScroll = function () {
    document.body.classList.toggle('tc-scrolled', window.scrollY > 40);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* gentle 3D tilt on project images (mouse devices only) */
  var fine = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  if (fine && !reduce) {
    var cards = document.querySelectorAll('.tc-pcard');
    Array.prototype.forEach.call(cards, function (c) {
      c.addEventListener('pointermove', function (e) {
        var r = c.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5;
        var y = (e.clientY - r.top) / r.height - 0.5;
        c.style.setProperty('--ry', (x * 7).toFixed(2) + 'deg');
        c.style.setProperty('--rx', (-y * 7).toFixed(2) + 'deg');
      });
      c.addEventListener('pointerleave', function () {
        c.style.setProperty('--rx', '0deg');
        c.style.setProperty('--ry', '0deg');
      });
    });
  }

  /* live company name in the footer: letters rise in, a light sweeps across them, and they lift near the cursor */
  var fw = document.querySelector('.tc-foot-word');
  if (fw) {
    var sp = fw.querySelectorAll('span');
    if (!('IntersectionObserver' in window) || reduce) {
      fw.classList.add('in');
    } else {
      new IntersectionObserver(function (en, o) {
        en.forEach(function (x) { if (x.isIntersecting) { fw.classList.add('in'); o.disconnect(); } });
      }, { threshold: 0.3 }).observe(fw);
      if (fine) {
        var ft = fw.parentNode, raf = 0, fx = null;
        var paint = function () {
          raf = 0;
          for (var q = 0; q < sp.length; q++) {
            var r = sp[q].getBoundingClientRect();
            var d = fx === null ? 1 : Math.abs(fx - (r.left + r.width / 2));
            sp[q].style.setProperty('--p', Math.max(0, 1 - d / 180).toFixed(3));
          }
        };
        ft.addEventListener('pointermove', function (e) { fx = e.clientX; if (!raf) { raf = requestAnimationFrame(paint); } });
        ft.addEventListener('pointerleave', function () { fx = null; if (!raf) { raf = requestAnimationFrame(paint); } });
      }
    }
  }
  /* project gallery: thumbnails (images and videos) show in the main box on the same page */
  var strip = document.getElementById('tc-strip');
  var stage = document.getElementById('tc-stage');
  var mainImg = document.getElementById('tc-main-img');
  var clearPlayer = function () {
    var old = stage.querySelector('.tc-player');
    if (old) { old.parentNode.removeChild(old); }
    stage.classList.remove('playing');
  };
  if (strip && stage) {
    strip.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('a') : null;
      if (!a) { return; }
      var k;
      var all = strip.querySelectorAll('a');
      if (a.classList.contains('tc-vid')) {
        e.preventDefault();
        var src = a.getAttribute('data-embed');
        if (!src) { return; }
        clearPlayer();
        var player;
        if (a.getAttribute('data-kind') === 'file') {
          player = document.createElement('video');
          player.controls = true;
          player.autoplay = true;
          player.setAttribute('playsinline', '');
          player.src = src;
          player.addEventListener('error', function () {
            var box = document.createElement('div');
            box.className = 'tc-player tc-player-err';
            var t = document.createElement('p');
            t.textContent = stage.getAttribute('data-vid-err') || '';
            var l = document.createElement('a');
            l.href = src;
            l.target = '_blank';
            l.rel = 'noopener';
            l.textContent = '\u25B6';
            box.appendChild(t);
            box.appendChild(l);
            if (player.parentNode) { player.parentNode.replaceChild(box, player); }
          });
        } else {
          player = document.createElement('iframe');
          player.setAttribute('allow', 'autoplay; encrypted-media; fullscreen; picture-in-picture');
          player.setAttribute('allowfullscreen', '');
          player.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
          player.setAttribute('title', 'Video');
          player.src = src;
        }
        player.className = 'tc-player';
        stage.appendChild(player);
        stage.classList.add('playing');
        for (k = 0; k < all.length; k++) { all[k].classList.remove('on'); }
        a.classList.add('on');
        return;
      }
      var full = a.getAttribute('data-full');
      if (!full) { return; }
      e.preventDefault();
      clearPlayer();
      for (k = 0; k < all.length; k++) { all[k].classList.remove('on'); }
      a.classList.add('on');
      if (!mainImg || mainImg.getAttribute('src') === full) { return; }
      mainImg.classList.add('fade');
      var pre = new Image();
      var apply = function () {
        mainImg.removeAttribute('srcset');
        mainImg.removeAttribute('sizes');
        mainImg.src = full;
        mainImg.classList.remove('fade');
      };
      pre.onload = apply;
      pre.onerror = apply;
      pre.src = full;
    });
  }

  /* email inquiry form (modal) */
  var modal = document.getElementById('tc-inq');
  if (modal) {
    var form = modal.querySelector('form');
    var msg = modal.querySelector('.tc-inq-msg');
    var projBox = modal.querySelector('.tc-inq-proj');
    var projIn = form.querySelector('[name=project]');
    var elIn = form.querySelector('[name=el]');
    var btn = form.querySelector('button[type=submit]');
    var opened = 0;
    var lastFocus = null;
    var showMsg = function (text, good) {
      msg.textContent = text;
      msg.className = 'tc-inq-msg' + (good ? ' ok' : ' err');
      msg.hidden = false;
    };
    var openModal = function (project, trigger) {
      lastFocus = trigger || null;
      projIn.value = project || '';
      if (project) {
        projBox.querySelector('span').textContent = project;
        projBox.hidden = false;
      } else {
        projBox.hidden = true;
      }
      msg.hidden = true;
      form.hidden = false;
      modal.hidden = false;
      document.documentElement.classList.add('tc-modal-open');
      opened = Date.now();
      var first = form.querySelector('input[name=name]');
      if (first) { first.focus(); }
    };
    var closeModal = function () {
      modal.hidden = true;
      document.documentElement.classList.remove('tc-modal-open');
      if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
    };
    document.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target.closest('[data-tc-inquiry]') : null;
      if (t) {
        e.preventDefault();
        openModal(t.getAttribute('data-project') || '', t);
        return;
      }
      if (!modal.hidden && (e.target === modal || (e.target.closest && e.target.closest('[data-tc-inq-close]')))) {
        closeModal();
      }
    });
    document.addEventListener('keydown', function (e) {
      if (modal.hidden) { return; }
      if (e.key === 'Escape') { closeModal(); return; }
      if (e.key === 'Tab') {
        var f = modal.querySelectorAll('button, input:not([type=hidden]):not([tabindex="-1"]), select, textarea');
        var vis = [];
        for (var n = 0; n < f.length; n++) { if (f[n].offsetParent !== null) { vis.push(f[n]); } }
        if (!vis.length) { return; }
        var firstEl = vis[0];
        var lastEl = vis[vis.length - 1];
        if (e.shiftKey && document.activeElement === firstEl) { e.preventDefault(); lastEl.focus(); }
        else if (!e.shiftKey && document.activeElement === lastEl) { e.preventDefault(); firstEl.focus(); }
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      elIn.value = String(Date.now() - opened);
      btn.disabled = true;
      btn.textContent = btn.getAttribute('data-sending');
      msg.hidden = true;
      var done = function () {
        btn.disabled = false;
        btn.textContent = btn.getAttribute('data-label');
      };
      fetch(form.getAttribute('data-url'), { method: 'POST', body: new FormData(form), credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          done();
          var text = (res && res.data && res.data.message) ? res.data.message : '';
          if (res && res.success) {
            form.reset();
            form.hidden = true;
            showMsg(text, true);
          } else {
            showMsg(text, false);
          }
        })
        .catch(function () {
          done();
          showMsg(modal.getAttribute('data-err') || 'Error', false);
        });
    });
  }
})();
