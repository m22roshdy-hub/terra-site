/* Living city: an isometric skyline of plots and buildings that rise and fall like a wave of construction. */
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function hash(x, y) {
    var h = (Math.imul(x, 374761393) + Math.imul(y, 668265263)) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
  }
  function sm(t) { return t * t * (3 - 2 * t); }

  function init(cv) {
    var ctx = cv.getContext('2d');
    if (!ctx) { return; }
    var tw0 = parseInt(cv.getAttribute('data-cell') || '70', 10);
    var cxr = parseFloat(cv.getAttribute('data-cx') || '0.5');
    var mouse = cv.getAttribute('data-mouse') === '1';
    var W = 1, H = 1, dpr = 1, N = 20, lots = [];
    var t = Math.random() * 40, mx = -9999, my = -9999, vis = true, last = 0;
    var hI = -1, hJ = -1, hAmt = 0;

    function build() {
      lots = [];
      for (var i = 0; i < N; i++) {
        for (var j = 0; j < N; j++) {
          var r = hash(i + 7, j + 3), r2 = hash(j + 19, i + 11);
          var dx = i - N / 2, dy = j - N / 2;
          var d = Math.sqrt(dx * dx + dy * dy) / (N / 2);
          var type, h;
          if (r < 0.26) { type = 0; h = 0; }
          else if (r < 0.62) { type = 1; h = tw0 * (0.22 + 0.3 * r2); }
          else { type = 2; h = tw0 * (0.8 + 1.9 * r2) * Math.max(0.35, 1.15 - d * 0.8); }
          lots.push({ t: type, h: h, ph: r * 6.283 });
        }
      }
    }

    function size() {
      var r = cv.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      W = Math.max(1, Math.round(r.width));
      H = Math.max(1, Math.round(r.height));
      cv.width = Math.round(W * dpr);
      cv.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      N = Math.min(36, Math.ceil(W / tw0) + 6);
      build();
    }

    function frame() {
      var tw = tw0, th = tw * 0.5, ox = W * cxr, oy = H * 0.56 - N * th / 2;
      var px = 0, py = 0, i, j, s, lot, k, h;
      function P(x, y, z) { px = ox + (x - y) * tw / 2; py = oy + (x + y) * th / 2 - z; }
      ctx.clearRect(0, 0, W, H);
      ctx.lineJoin = 'round';

      var ci = -1, cj = -1;
      if (mx > -999) {
        var a = (mx - ox) / (tw / 2), b = (my - oy) / (th / 2);
        ci = Math.floor((a + b) / 2);
        cj = Math.floor((b - a) / 2);
        if (ci < 0 || cj < 0 || ci >= N || cj >= N) { ci = -1; cj = -1; }
      }
      if (ci !== hI || cj !== hJ) { hI = ci; hJ = cj; hAmt = 0; }
      if (hI >= 0) { hAmt += (1 - hAmt) * 0.18; }

      for (s = 0; s <= 2 * N - 2; s++) {
        for (i = Math.max(0, s - N + 1); i <= Math.min(s, N - 1); i++) {
          j = s - i;
          lot = lots[i * N + j];
          var hov = (i === hI && j === hJ);
          k = reduce ? 1 : sm(0.5 + 0.5 * Math.sin(t * 0.35 + (i + j) * 0.32 + lot.ph));
          h = lot.t === 0 ? 0 : lot.h * (0.12 + 0.88 * k);
          if (hov) { h += tw * 0.6 * hAmt; }

          var m = (h < 1.5) ? 0.08 : 0.2;
          var x0 = i + m, x1 = i + 1 - m, y0 = j + m, y1 = j + 1 - m;
          P(x0, y0, 0); var Ax = px, Ay = py;
          P(x1, y0, 0); var Bx = px, By = py;
          P(x1, y1, 0); var Cx = px, Cy = py;
          P(x0, y1, 0); var Dx = px, Dy = py;
          if (Bx < -20 || Dx > W + 20 || Cy < -20 || Ay - h > H + 20) { continue; }

          if (h < 1.5) {
            ctx.beginPath();
            ctx.moveTo(Ax, Ay); ctx.lineTo(Bx, By); ctx.lineTo(Cx, Cy); ctx.lineTo(Dx, Dy); ctx.closePath();
            ctx.strokeStyle = 'rgba(201,139,98,0.22)';
            ctx.lineWidth = 1;
            ctx.stroke();
            continue;
          }

          var A2 = Ay - h, B2 = By - h, C2 = Cy - h, D2 = Dy - h;
          ctx.fillStyle = '#070605';
          ctx.beginPath();
          ctx.moveTo(Dx, Dy); ctx.lineTo(Cx, Cy); ctx.lineTo(Bx, By); ctx.lineTo(Bx, B2); ctx.lineTo(Ax, A2); ctx.lineTo(Dx, D2);
          ctx.closePath(); ctx.fill();

          ctx.fillStyle = 'rgba(201,139,98,0.05)';
          ctx.beginPath(); ctx.moveTo(Dx, Dy); ctx.lineTo(Cx, Cy); ctx.lineTo(Cx, C2); ctx.lineTo(Dx, D2); ctx.closePath(); ctx.fill();
          ctx.fillStyle = 'rgba(201,139,98,0.1)';
          ctx.beginPath(); ctx.moveTo(Cx, Cy); ctx.lineTo(Bx, By); ctx.lineTo(Bx, B2); ctx.lineTo(Cx, C2); ctx.closePath(); ctx.fill();
          ctx.fillStyle = hov ? 'rgba(240,195,154,0.3)' : 'rgba(240,195,154,0.09)';
          ctx.beginPath(); ctx.moveTo(Ax, A2); ctx.lineTo(Bx, B2); ctx.lineTo(Cx, C2); ctx.lineTo(Dx, D2); ctx.closePath(); ctx.fill();

          var al = hov ? 0.95 : 0.3 + 0.35 * k;
          var col = hov ? '240,195,154' : '201,139,98';
          ctx.lineWidth = 1;
          ctx.strokeStyle = 'rgba(' + col + ',' + al.toFixed(3) + ')';
          ctx.beginPath();
          ctx.moveTo(Dx, Dy); ctx.lineTo(Cx, Cy); ctx.lineTo(Bx, By); ctx.lineTo(Bx, B2); ctx.lineTo(Ax, A2); ctx.lineTo(Dx, D2); ctx.closePath();
          ctx.moveTo(Cx, Cy); ctx.lineTo(Cx, C2);
          ctx.stroke();
          ctx.strokeStyle = 'rgba(240,195,154,' + Math.min(1, al + 0.15).toFixed(3) + ')';
          ctx.beginPath();
          ctx.moveTo(Ax, A2); ctx.lineTo(Bx, B2); ctx.lineTo(Cx, C2); ctx.lineTo(Dx, D2); ctx.closePath();
          ctx.stroke();

          var fh = tw * 0.17;
          if (h > tw * 0.5) {
            var cnt = Math.min(10, Math.floor(h / fh));
            ctx.strokeStyle = 'rgba(201,139,98,0.14)';
            ctx.beginPath();
            for (var f = 1; f < cnt; f++) {
              ctx.moveTo(Dx, Dy - f * fh); ctx.lineTo(Cx, Cy - f * fh); ctx.lineTo(Bx, By - f * fh);
            }
            ctx.stroke();
          }
        }
      }
    }

    function loop(ts) {
      requestAnimationFrame(loop);
      if (!vis || document.hidden) { return; }
      if (ts - last < 33) { return; }
      last = ts;
      t += 0.033;
      frame();
    }

    size();
    frame();

    var timer = null;
    window.addEventListener('resize', function () {
      clearTimeout(timer);
      timer = setTimeout(function () { size(); frame(); }, 150);
    });

    if (reduce) { return; }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { vis = en[0].isIntersecting; }).observe(cv);
    }
    if (mouse) {
      window.addEventListener('pointermove', function (e) {
        var r = cv.getBoundingClientRect();
        if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) {
          mx = e.clientX - r.left;
          my = e.clientY - r.top;
        } else {
          mx = -9999;
        }
      }, { passive: true });
    }
    requestAnimationFrame(loop);
  }

  var cvs = document.querySelectorAll('canvas.tc-skyline');
  for (var n = 0; n < cvs.length; n++) { init(cvs[n]); }
})();
