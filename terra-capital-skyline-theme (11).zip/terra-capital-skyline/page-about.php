<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main>
	<section class="tc-sec">
		<div class="tc-about-top">
			<h1 class="tc-h2 tc-shine"><?php echo esc_html(tc('aboutTitle')); ?></h1>
			<div>
				<p class="tc-statement"><?php echo esc_html(tc('aboutP1')); ?></p>
				<h2 class="tc-sub-h"><?php echo esc_html(tc('aboutAllyT')); ?></h2>
				<p class="tc-lead"><?php echo esc_html(tc('aboutP2')); ?></p>
				<p class="tc-lead"><?php echo esc_html(tc('aboutP3')); ?></p>
			</div>
		</div>
		<div class="tc-pillars">
			<?php for ($i = 1; $i <= 3; $i++) : ?>
				<div class="tc-pillar tc-reveal">
					<div class="n"><?php printf('%02d', $i); ?></div>
					<h3><?php echo esc_html(tc('pil' . $i . 'T')); ?></h3>
					<p><?php echo esc_html(tc('pil' . $i . 'D')); ?></p>
				</div>
			<?php endfor; ?>
		</div>
	</section>
	<section class="tc-mission">
		<canvas class="tc-skyline" aria-hidden="true" data-cell="84" data-mouse="0"></canvas>
		<div class="tc-above">
			<h2><?php echo esc_html(tc('missionT')); ?></h2>
			<p><?php echo esc_html(tc('missionD')); ?></p>
		</div>
	</section>
	<?php get_template_part('template-parts/credentials'); ?>
</main>
<?php get_footer(); ?>
