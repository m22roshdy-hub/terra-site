<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main class="tc-sec">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<h1 class="tc-h2"><?php the_title(); ?></h1>
			<div class="tc-desc"><?php the_content(); ?></div>
		<?php endwhile; ?>
	<?php else : ?>
		<h1 class="tc-h2"><?php echo esc_html(tc('notFound')); ?></h1>
		<p class="tc-lead"><a href="<?php echo esc_url(tc_page_url('home')); ?>"><?php echo esc_html(tc('navHome')); ?></a></p>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
