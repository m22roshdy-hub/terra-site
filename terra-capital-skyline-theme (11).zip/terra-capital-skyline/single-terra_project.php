<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main class="tc-sec">
<?php while (have_posts()) : the_post(); ?>
	<?php
	$tc_id = get_the_ID();
	$tc_name = tc_project_name($tc_id);
	$tc_place = tc_project_field($tc_id, 'place');
	$tc_type = tc_project_type_label($tc_id);
	$tc_desc = tc_project_field($tc_id, 'desc');
	$tc_wa = tc_whatsapp_url(str_replace('%s', $tc_name, tc('waMsg')));
	$tc_gal = tc_project_gallery($tc_id);
	$tc_thumb = (int) get_post_thumbnail_id($tc_id);
	$tc_imgs = array();
	if ($tc_thumb > 0) {
		$tc_imgs[] = $tc_thumb;
	}
	foreach ($tc_gal as $tc_g) {
		if (!in_array($tc_g, $tc_imgs, true)) {
			$tc_imgs[] = $tc_g;
		}
	}
	$tc_main = $tc_imgs ? $tc_imgs[0] : 0;
	$tc_vids = tc_project_videos($tc_id);
	$tc_map = tc_project_map_url($tc_id);
	$tc_faq = tc_faq_pick(tc_faq_project_all($tc_id));
	$tc_arrow = (tc_dir() === 'rtl') ? '→' : '←';
	?>
	<a class="tc-back" href="<?php echo esc_url(tc_page_url('projects')); ?>"><?php echo esc_html($tc_arrow . ' ' . tc('back')); ?></a>
	<div class="tc-single">
		<div>
			<div class="tc-stage" id="tc-stage" data-vid-err="<?php echo esc_attr(tc('vidErr')); ?>">
				<?php if ($tc_main) : ?>
					<?php echo wp_get_attachment_image($tc_main, 'large', false, array('class' => 'tc-single-main', 'id' => 'tc-main-img', 'alt' => $tc_name)); ?>
				<?php else : ?>
					<div class="tc-single-ph"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo.png'); ?>" alt=""></div>
				<?php endif; ?>
			</div>
			<?php if (count($tc_imgs) > 1 || $tc_vids) : ?>
				<div class="tc-strip" id="tc-strip">
					<?php foreach ($tc_imgs as $tc_i => $tc_att) : ?>
						<?php $tc_large = wp_get_attachment_image_url($tc_att, 'large'); ?>
						<?php if ($tc_large) : ?>
							<a href="<?php echo esc_url($tc_large); ?>" data-full="<?php echo esc_url($tc_large); ?>"<?php echo $tc_i === 0 ? ' class="on"' : ''; ?>><?php echo wp_get_attachment_image($tc_att, 'medium', false, array('loading' => 'lazy', 'alt' => $tc_name)); ?></a>
						<?php endif; ?>
					<?php endforeach; ?>
					<?php foreach ($tc_vids as $tc_v) : ?>
						<a class="tc-vid" href="<?php echo esc_url($tc_v['url']); ?>" data-kind="<?php echo esc_attr($tc_v['type']); ?>" data-embed="<?php echo esc_url($tc_v['embed']); ?>">
							<?php if ($tc_v['thumb'] !== '') : ?><img src="<?php echo esc_url($tc_v['thumb']); ?>" alt="" loading="lazy"><?php else : ?><span class="tc-vph"></span><?php endif; ?>
							<span class="tc-play" aria-hidden="true"></span>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<div class="tc-single-info">
			<span class="tc-badge"><?php echo esc_html(tc('status.' . tc_project_status_key($tc_id))); ?></span>
			<h1><?php echo esc_html($tc_name); ?></h1>
			<?php if ($tc_place !== '') : ?><p class="tc-muted" style="margin:10px 0 0"><?php echo esc_html($tc_place); ?></p><?php endif; ?>
			<?php if ($tc_type !== '') : ?><p class="tc-cat"><?php echo esc_html($tc_type); ?></p><?php endif; ?>
			<div class="price"><?php echo esc_html(tc('price') . ': ' . tc_project_price($tc_id)); ?></div>
			<?php if ($tc_desc !== '') : ?><div class="tc-desc"><?php echo wp_kses_post(wpautop(esc_html($tc_desc))); ?></div><?php endif; ?>
			<div class="tc-row">
				<a class="tc-btn" href="<?php echo esc_url($tc_wa); ?>" target="_blank" rel="noopener"><?php echo esc_html(tc('inquire')); ?></a>
				<?php tc_inquiry_button($tc_name); ?>
				<?php if ($tc_map !== '') : ?><a class="tc-btn-o" href="<?php echo esc_url($tc_map); ?>" target="_blank" rel="noopener"><?php echo tc_icon_pin(); ?> <?php echo esc_html(tc('mapBtn')); ?></a><?php endif; ?>
				<a class="tc-btn-o" href="<?php echo esc_url(tc_page_url('projects')); ?>"><?php echo esc_html(tc('back')); ?></a>
			</div>
		</div>
	</div>
	<div class="tc-faq-wrap"><?php tc_faq_render($tc_faq); ?></div>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
