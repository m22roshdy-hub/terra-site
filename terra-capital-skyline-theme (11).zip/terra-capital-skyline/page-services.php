<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main>
	<section class="tc-sec">
		<h1 class="tc-h2 tc-shine"><?php echo esc_html(tc('svcTitle')); ?></h1>
		<?php get_template_part('template-parts/services-list'); ?>
	</section>
	<?php get_template_part('template-parts/contact'); ?>
</main>
<?php get_footer(); ?>
