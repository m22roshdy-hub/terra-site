<?php
if (!defined('ABSPATH')) exit;

define('TC_VERSION', '2.3.5');
define('TC_LANGS', array('ar', 'en', 'de', 'ru'));

require_once get_template_directory() . '/inc/strings.php';
require_once get_template_directory() . '/inc/svg.php';
require_once get_template_directory() . '/inc/projects.php';
require_once get_template_directory() . '/inc/faq.php';
require_once get_template_directory() . '/inc/video.php';
require_once get_template_directory() . '/inc/inquiry.php';
require_once get_template_directory() . '/inc/admin.php';

/* ---------- Settings ---------- */

function tc_defaults() {
	return array(
		'whatsapp'     => '201221752000',
		'phone'        => '+20 122 175 2000',
		'email'        => 'info@terracapitaleg.com',
		'address'      => '612 Zahabia st. Hurghada, Red Sea, Egypt',
		'facebook'     => 'https://www.facebook.com/profile.php?id=61595954909547',
		'cr'           => '293634',
		'tax'          => '780-967-178',
		'default_lang' => 'en',
	);
}

function tc_settings() {
	$saved = get_option('terra_settings', array());
	if (!is_array($saved)) {
		$saved = array();
	}
	return array_merge(tc_defaults(), $saved);
}

function tc_opt($key) {
	$o = tc_settings();
	return isset($o[$key]) ? $o[$key] : '';
}

/* ---------- Language (URL based: ?lang=ar|en|de|ru) ---------- */

function tc_default_lang() {
	$l = tc_opt('default_lang');
	return in_array($l, TC_LANGS, true) ? $l : 'en';
}

function tc_lang() {
	static $lang = null;
	if ($lang === null) {
		$lang = tc_default_lang();
		if (isset($_GET['lang'])) {
			$g = sanitize_key(wp_unslash($_GET['lang']));
			if (in_array($g, TC_LANGS, true)) {
				$lang = $g;
			}
		}
	}
	return $lang;
}

function tc_dir() {
	return tc_lang() === 'ar' ? 'rtl' : 'ltr';
}

function tc_lang_names() {
	return array(
		'ar' => 'العربية',
		'en' => 'English',
		'de' => 'Deutsch',
		'ru' => 'Русский',
	);
}

/* ---------- Texts (defaults + overrides from Terra Capital > Texts) ---------- */

function tc($key, $lang = null) {
	if ($lang === null) {
		$lang = tc_lang();
	}
	static $overrides = null;
	if ($overrides === null) {
		$overrides = get_option('terra_texts', array());
		if (!is_array($overrides)) {
			$overrides = array();
		}
	}
	if (isset($overrides[$lang][$key]) && $overrides[$lang][$key] !== '') {
		return $overrides[$lang][$key];
	}
	$defaults = tc_strings();
	if (isset($defaults[$lang][$key])) {
		return $defaults[$lang][$key];
	}
	if (isset($defaults['en'][$key])) {
		return $defaults['en'][$key];
	}
	return $key;
}

/* ---------- URLs ---------- */

function tc_with_lang($url, $lang = null) {
	if ($lang === null) {
		$lang = tc_lang();
	}
	$url = remove_query_arg('lang', $url);
	if ($lang !== tc_default_lang()) {
		$url = add_query_arg('lang', $lang, $url);
	}
	return $url;
}

function tc_page_url($slug) {
	static $cache = array();
	if (isset($cache[$slug])) {
		return $cache[$slug];
	}
	if ($slug === 'home') {
		$url = home_url('/');
	} else {
		$page = get_page_by_path($slug);
		$url = ($page && $page->post_status === 'publish') ? get_permalink($page) : home_url('/' . $slug . '/');
	}
	$cache[$slug] = tc_with_lang($url);
	return $cache[$slug];
}

function tc_current_base() {
	if (is_singular()) {
		return get_permalink();
	}
	return home_url('/');
}

function tc_current_slug() {
	if (is_front_page()) {
		return 'home';
	}
	if (is_singular('terra_project')) {
		return 'projects';
	}
	foreach (array('about', 'services', 'projects', 'faq', 'contact') as $s) {
		if (is_page($s)) {
			return $s;
		}
	}
	return '';
}

function tc_whatsapp_url($message = '') {
	$url = 'https://wa.me/' . preg_replace('/\D+/', '', tc_opt('whatsapp'));
	if ($message !== '') {
		$url .= '?text=' . rawurlencode($message);
	}
	return $url;
}

/* ---------- Theme setup ---------- */

add_action('after_setup_theme', function () {
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script'));
	add_image_size('tc-card', 900, 600, true);
});

add_action('wp_enqueue_scripts', function () {
	wp_enqueue_style('tc-fonts', 'https://fonts.googleapis.com/css2?family=Cinzel:wght@600;800&family=Unbounded:wght@500;700;800&family=Manrope:wght@400;600;800&family=Noto+Kufi+Arabic:wght@500;700;800&family=Noto+Sans+Arabic:wght@400;600;800&display=swap', array(), null);
	wp_enqueue_style('tc-style', get_stylesheet_uri(), array(), TC_VERSION);
	wp_enqueue_script('tc-skyline', get_template_directory_uri() . '/assets/skyline.js', array(), TC_VERSION, true);
	wp_enqueue_script('tc-main', get_template_directory_uri() . '/assets/main.js', array(), TC_VERSION, true);
});

add_filter('language_attributes', function ($output) {
	return 'lang="' . esc_attr(tc_lang()) . '" dir="' . esc_attr(tc_dir()) . '"';
});

add_filter('pre_get_document_title', function ($title) {
	$brand = tc('brand');
	if (is_front_page()) {
		return $brand . ' | ' . tc('heroTitle');
	}
	if (is_singular('terra_project')) {
		return tc_project_name(get_the_ID()) . ' | ' . $brand;
	}
	$map = array('about' => 'navAbout', 'services' => 'navServices', 'projects' => 'navProjects', 'faq' => 'navFaq', 'contact' => 'navContact');
	foreach ($map as $slug => $key) {
		if (is_page($slug)) {
			return tc($key) . ' | ' . $brand;
		}
	}
	return $title;
});

add_action('init', function () {
	remove_action('wp_head', 'rel_canonical');
});

add_action('wp_head', function () {
	if (is_front_page()) {
		echo '<meta name="description" content="' . esc_attr(tc('metaDesc')) . '">' . "\n";
	}
	if (is_singular()) {
		$base = get_permalink();
		/* each language version is its own canonical page (WordPress would point all of them at the default-language URL) */
		echo '<link rel="canonical" href="' . esc_url(tc_with_lang($base, tc_lang())) . '">' . "\n";
		foreach (TC_LANGS as $l) {
			echo '<link rel="alternate" hreflang="' . esc_attr($l) . '" href="' . esc_url(tc_with_lang($base, $l)) . '">' . "\n";
		}
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url(tc_with_lang($base, tc_default_lang())) . '">' . "\n";
	}
	if (!has_site_icon()) {
		echo '<link rel="icon" href="' . esc_url(get_template_directory_uri() . '/assets/logo.png') . '">' . "\n";
	}
});

/* ---------- On activation: create the five pages and set the front page ---------- */

function tc_activate() {
	tc_register_cpt();
	$pages = array(
		'home'     => 'Home',
		'about'    => 'About',
		'services' => 'Services',
		'projects' => 'Projects',
		'faq'      => 'FAQ',
		'contact'  => 'Contact us',
	);
	$ids = array();
	foreach ($pages as $slug => $title) {
		$existing = get_page_by_path($slug);
		if ($existing) {
			if ($existing->post_status !== 'publish') {
				wp_update_post(array('ID' => $existing->ID, 'post_status' => 'publish'));
			}
			$ids[$slug] = $existing->ID;
			continue;
		}
		$ids[$slug] = wp_insert_post(array(
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_content' => '',
		));
	}
	update_option('show_on_front', 'page');
	update_option('page_on_front', $ids['home']);
	flush_rewrite_rules();
}
add_action('after_switch_theme', 'tc_activate');


/* Create the FAQ page once on sites that were activated before it existed */
add_action('init', function () {
	if (get_option('tc_faq_page_v1')) {
		return;
	}
	$existing = get_page_by_path('faq');
	if ($existing) {
		if ($existing->post_status !== 'publish') {
			wp_update_post(array('ID' => $existing->ID, 'post_status' => 'publish'));
		}
	} else {
		wp_insert_post(array(
			'post_title'   => 'FAQ',
			'post_name'    => 'faq',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_content' => '',
		));
	}
	update_option('tc_faq_page_v1', 1);
	flush_rewrite_rules();
}, 30);
