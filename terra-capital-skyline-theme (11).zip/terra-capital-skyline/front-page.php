<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main>
	<section class="tc-hero">
		<canvas class="tc-skyline" aria-hidden="true" data-cell="68" data-cx="0.62" data-mouse="1"></canvas>
		<div class="tc-above">
			<div class="rise"><h1 class="tc-shine"><?php echo esc_html(tc('heroTitle')); ?></h1></div>
			<p class="tc-lead rise d1"><?php echo esc_html(tc('heroSub')); ?></p>
			<a class="tc-btn rise d2" href="<?php echo esc_url(tc_page_url('projects')); ?>"><?php echo esc_html(tc('cta')); ?></a>
		</div>
		<div class="tc-emblem tc-above" aria-hidden="true">
			<?php echo tc_ring_svg(); ?>
			<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo.png'); ?>" alt="">
		</div>
	</section>

	<div class="tc-marquee" aria-hidden="true">
		<div class="tc-track">
			<?php
			for ($tc_r = 0; $tc_r < 4; $tc_r++) {
				for ($tc_i = 1; $tc_i <= 4; $tc_i++) {
					echo '<span class="tc-mi" dir="auto">' . esc_html(tc('svc' . $tc_i . 'T')) . tc_icon_diamond() . '</span>';
				}
			}
			?>
		</div>
	</div>

	<section class="tc-sec">
		<h2 class="tc-h2 tc-reveal"><?php echo esc_html(tc('svcTitle')); ?></h2>
		<?php get_template_part('template-parts/services-list'); ?>
		<a class="tc-more" href="<?php echo esc_url(tc_page_url('services')); ?>"><?php echo esc_html(tc('navServices')); ?> <?php echo tc_icon_arrow(); ?></a>
	</section>

	<?php get_template_part('template-parts/credentials'); ?>
	<?php get_template_part('template-parts/contact'); ?>
</main>
<?php get_footer(); ?>
