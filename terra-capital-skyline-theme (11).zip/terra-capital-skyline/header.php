<?php if (!defined('ABSPATH')) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>document.documentElement.className += ' js';</script>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php if (function_exists('wp_body_open')) { wp_body_open(); } ?>
<header class="tc-header">
	<a class="tc-brand" href="<?php echo esc_url(tc_page_url('home')); ?>">
		<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo.png'); ?>" alt="">
		<span><?php echo esc_html(tc('brand')); ?></span>
	</a>
	<div class="tc-hd">
		<nav class="tc-navs" aria-label="Main">
			<?php
			$tc_nav = array(
				'home'     => 'navHome',
				'about'    => 'navAbout',
				'services' => 'navServices',
				'projects' => 'navProjects',
				'faq'      => 'navFaq',
				'contact'  => 'navContact',
			);
			$tc_cur = tc_current_slug();
			foreach ($tc_nav as $tc_slug => $tc_key) {
				$tc_on = ($tc_slug === $tc_cur) ? ' on' : '';
				echo '<a class="tc-nav' . $tc_on . '" href="' . esc_url(tc_page_url($tc_slug)) . '">' . esc_html(tc($tc_key)) . '</a>';
			}
			?>
		</nav>
		<div class="tc-langs">
			<?php
			$tc_base = tc_current_base();
			foreach (tc_lang_names() as $tc_code => $tc_name) {
				$tc_on = ($tc_code === tc_lang()) ? ' on' : '';
				echo '<a class="tc-lang' . $tc_on . '" href="' . esc_url(tc_with_lang($tc_base, $tc_code)) . '" hreflang="' . esc_attr($tc_code) . '" lang="' . esc_attr($tc_code) . '">' . tc_flag($tc_code) . esc_html($tc_name) . '</a>';
			}
			?>
		</div>
	</div>
</header>
