<?php
if (!defined('ABSPATH')) exit;

/* ================= Project videos (YouTube / Vimeo / MP4 link) ================= */

function tc_video_parse($url) {
	$url = trim((string) $url);
	if ($url === '') {
		return null;
	}
	if (strpos($url, '/') === 0 && strpos($url, '//') !== 0) {
		$url = home_url($url);
	}
	$home_host = wp_parse_url(home_url(), PHP_URL_HOST);
	$url_host = wp_parse_url($url, PHP_URL_HOST);
	if ($home_host && $url_host && strtolower($home_host) === strtolower($url_host) && stripos($url, 'http://') === 0) {
		$url = 'https://' . substr($url, 7);
	}
	$u = esc_url_raw($url, array('https'));
	if ($u === '') {
		return null;
	}
	$p = wp_parse_url($u);
	if (empty($p['host'])) {
		return null;
	}
	$host = strtolower(preg_replace('/^www\./', '', $p['host']));
	$path = isset($p['path']) ? $p['path'] : '';
	$q = array();
	if (!empty($p['query'])) {
		parse_str($p['query'], $q);
	}

	$id = '';
	if ($host === 'youtu.be') {
		$id = trim($path, '/');
	} elseif (in_array($host, array('youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtube-nocookie.com'), true)) {
		if ($path === '/watch' && !empty($q['v']) && is_string($q['v'])) {
			$id = $q['v'];
		} elseif (preg_match('#^/(embed|shorts|live|v)/([A-Za-z0-9_-]{6,15})#', $path, $m)) {
			$id = $m[2];
		}
	}
	if ($id !== '' && preg_match('/^[A-Za-z0-9_-]{6,15}$/', $id)) {
		return array(
			'type'  => 'youtube',
			'url'   => $u,
			'embed' => 'https://www.youtube-nocookie.com/embed/' . $id . '?autoplay=1&rel=0',
			'thumb' => 'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg',
		);
	}

	if (in_array($host, array('vimeo.com', 'player.vimeo.com'), true) && preg_match('#^(?:/video)?/(\d{6,12})(?:/([A-Za-z0-9]{6,}))?#', $path, $m)) {
		$embed = 'https://player.vimeo.com/video/' . $m[1] . '?autoplay=1';
		if (!empty($m[2])) {
			$embed .= '&h=' . $m[2];
		} elseif (!empty($q['h']) && is_string($q['h']) && preg_match('/^[A-Za-z0-9]{6,}$/', $q['h'])) {
			$embed .= '&h=' . $q['h'];
		}
		return array('type' => 'vimeo', 'url' => $u, 'embed' => $embed, 'thumb' => '');
	}

	if (preg_match('/\.(mp4|m4v|webm)$/i', $path)) {
		return array('type' => 'file', 'url' => $u, 'embed' => $u, 'thumb' => '');
	}
	return null;
}

function tc_video_sanitize($raw) {
	$out = array();
	foreach (preg_split('/\r\n|\r|\n/', (string) $raw) as $line) {
		$v = tc_video_parse($line);
		if ($v) {
			$out[] = $v['url'];
			if (count($out) >= 3) {
				break;
			}
		}
	}
	return implode("\n", $out);
}

function tc_project_videos($post_id) {
	$list = array();
	foreach (preg_split('/\r\n|\r|\n/', (string) get_post_meta($post_id, 'videos', true)) as $line) {
		$v = tc_video_parse($line);
		if ($v) {
			$list[] = $v;
		}
	}
	return array_slice($list, 0, 3);
}
