<?php
if (!defined('ABSPATH')) exit;

/* Country flags for the language switcher (static, trusted markup). */
function tc_flag($code) {
	$open = '<svg width="21" height="14" viewBox="0 0 3 2" aria-hidden="true" focusable="false">';
	switch ($code) {
		case 'ar':
			return $open . '<rect width="3" height="2" fill="#000000"/><rect width="3" height="1.34" fill="#FFFFFF"/><rect width="3" height="0.67" fill="#CE1126"/><circle cx="1.5" cy="1" r="0.2" fill="#C09300"/></svg>';
		case 'de':
			return $open . '<rect width="3" height="2" fill="#FFCE00"/><rect width="3" height="1.34" fill="#DD0000"/><rect width="3" height="0.67" fill="#000000"/></svg>';
		case 'ru':
			return $open . '<rect width="3" height="2" fill="#D52B1E"/><rect width="3" height="1.34" fill="#0039A6"/><rect width="3" height="0.67" fill="#FFFFFF"/></svg>';
		case 'en':
			return '<svg width="21" height="14" viewBox="0 0 60 40" preserveAspectRatio="none" aria-hidden="true" focusable="false"><rect width="60" height="40" fill="#012169"/><path d="M0,0L60,40M60,0L0,40" stroke="#FFFFFF" stroke-width="8"/><path d="M0,0L60,40M60,0L0,40" stroke="#C8102E" stroke-width="3"/><path d="M30,0V40M0,20H60" stroke="#FFFFFF" stroke-width="13"/><path d="M30,0V40M0,20H60" stroke="#C8102E" stroke-width="8"/></svg>';
	}
	return '';
}

/* Copper line illustrations for the four services (static, trusted markup). */
function tc_service_art($i) {
	$head = '<svg viewBox="0 0 320 170" width="100%" height="170" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><g fill="none" stroke="#C98B62" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">';
	$tail = '</g></svg>';
	$art = array(
		1 => '<path d="M30 140H290"/><rect x="60" y="110" width="30" height="30"/><rect x="110" y="90" width="30" height="50"/><rect x="160" y="68" width="30" height="72"/><rect x="210" y="42" width="30" height="98"/><path d="M50 100L120 74L170 56L235 24" stroke="#E8B992"/><path d="M215 24H235V44" stroke="#E8B992"/>',
		2 => '<circle cx="150" cy="88" r="52"/><ellipse cx="150" cy="88" rx="22" ry="52"/><path d="M98 88H202M108 63H192M108 113H192"/><path d="M232 38c-10 0-17 7-17 16 0 12 17 28 17 28s17-16 17-28c0-9-7-16-17-16z" stroke="#E8B992"/><circle cx="232" cy="54" r="5" stroke="#E8B992"/>',
		3 => '<path d="M40 108C70 68 110 98 150 68S230 38 280 68"/><path d="M40 130C70 90 110 120 150 90S230 60 280 90"/><path d="M40 152C70 112 110 142 150 112S230 82 280 112"/><path d="M120 118L160 92L212 106L198 146Z" stroke="#E8B992"/>',
		4 => '<path d="M160 28L212 46V86C212 116 190 136 160 148C130 136 108 116 108 86V46Z"/><path d="M137 88l16 16 30-32" stroke="#E8B992" stroke-width="3"/>',
	);
	return isset($art[$i]) ? $head . $art[$i] . $tail : '';
}

function tc_icon_check() {
	return '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#C98B62" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
}

function tc_icon_facebook() {
	return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8.5c0-.3.2-.5.5-.5z"/></svg>';
}

/* Rotating survey ring (tick marks) drawn around the logo. */
function tc_ring_svg() {
	$out = '<svg viewBox="0 0 400 400" fill="none" stroke="#C98B62" aria-hidden="true" focusable="false">';
	$out .= '<circle cx="200" cy="200" r="196" stroke-opacity=".45"/>';
	$out .= '<circle cx="200" cy="200" r="150" stroke-opacity=".25" stroke-dasharray="2 8"/>';
	for ($i = 0; $i < 72; $i++) {
		$a = deg2rad($i * 5);
		$r1 = 196;
		$r2 = ($i % 6 === 0) ? 178 : 187;
		$x1 = round(200 + $r1 * cos($a), 2);
		$y1 = round(200 + $r1 * sin($a), 2);
		$x2 = round(200 + $r2 * cos($a), 2);
		$y2 = round(200 + $r2 * sin($a), 2);
		$out .= '<line x1="' . $x1 . '" y1="' . $y1 . '" x2="' . $x2 . '" y2="' . $y2 . '" stroke-opacity="' . (($i % 6 === 0) ? '.9' : '.5') . '"/>';
	}
	$out .= '</svg>';
	return $out;
}

function tc_icon_arrow() {
	return '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M7 17L17 7M9 7h8v8"/></svg>';
}

function tc_icon_diamond() {
	return '<svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true" focusable="false"><path d="M5 0L10 5L5 10L0 5Z" fill="#C98B62"/></svg>';
}

function tc_icon_pin() {
	return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.6"/></svg>';
}

function tc_icon_mail() {
	return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>';
}
