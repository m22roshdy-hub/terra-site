<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
	add_menu_page('Terra Capital', 'Terra Capital', 'manage_options', 'terra-settings', 'tc_page_settings', 'dashicons-admin-home', 58);
	add_submenu_page('terra-settings', 'Settings', 'Settings', 'manage_options', 'terra-settings', 'tc_page_settings');
	add_submenu_page('terra-settings', 'Texts', 'Texts', 'manage_options', 'terra-texts', 'tc_page_texts');
});

function tc_page_settings() {
	if (!current_user_can('manage_options')) {
		return;
	}
	$notice = '';
	if (isset($_POST['tc_save_settings']) && check_admin_referer('tc_settings_save')) {
		$in = (isset($_POST['tc']) && is_array($_POST['tc'])) ? wp_unslash($_POST['tc']) : array();
		$out = array();
		foreach (array('phone', 'email', 'address', 'cr', 'tax') as $k) {
			$out[$k] = sanitize_text_field(isset($in[$k]) ? $in[$k] : '');
		}
		$out['whatsapp'] = preg_replace('/\D+/', '', isset($in['whatsapp']) ? $in['whatsapp'] : '');
		$out['facebook'] = esc_url_raw(isset($in['facebook']) ? $in['facebook'] : '');
		$dl = isset($in['default_lang']) ? $in['default_lang'] : 'en';
		$out['default_lang'] = in_array($dl, TC_LANGS, true) ? $dl : 'en';
		update_option('terra_settings', $out);
		$notice = '<div class="notice notice-success"><p>Saved.</p></div>';
	}
	$cur = array_merge(tc_defaults(), (array) get_option('terra_settings', array()));
	$rows = array(
		'whatsapp' => 'WhatsApp number (digits only, with country code, e.g. 201221752000)',
		'phone'    => 'Phone (as shown on the site)',
		'email'    => 'Email',
		'address'  => 'Address',
		'facebook' => 'Facebook page link (leave empty to hide the button)',
		'cr'       => 'Commercial Register No.',
		'tax'      => 'Tax Registration No.',
	);
	echo '<div class="wrap"><h1>Terra Capital - Settings</h1>' . $notice;
	echo '<form method="post">';
	wp_nonce_field('tc_settings_save');
	echo '<table class="form-table" role="presentation">';
	foreach ($rows as $k => $label) {
		echo '<tr><th scope="row"><label for="tc_' . esc_attr($k) . '">' . esc_html($label) . '</label></th><td><input type="text" id="tc_' . esc_attr($k) . '" class="regular-text" name="tc[' . esc_attr($k) . ']" value="' . esc_attr($cur[$k]) . '"></td></tr>';
	}
	echo '<tr><th scope="row"><label for="tc_default_lang">Default language</label></th><td><select id="tc_default_lang" name="tc[default_lang]">';
	foreach (tc_lang_names() as $code => $name) {
		echo '<option value="' . esc_attr($code) . '"' . selected($cur['default_lang'], $code, false) . '>' . esc_html($name) . '</option>';
	}
	echo '</select></td></tr></table>';
	echo '<p class="submit"><input type="submit" name="tc_save_settings" class="button button-primary" value="Save settings"></p>';
	echo '</form></div>';
}

function tc_page_texts() {
	if (!current_user_can('manage_options')) {
		return;
	}
	$defaults = tc_strings();
	$notice = '';
	if (isset($_POST['tc_save_texts']) && check_admin_referer('tc_texts_save')) {
		$in = (isset($_POST['tx']) && is_array($_POST['tx'])) ? wp_unslash($_POST['tx']) : array();
		$out = array();
		foreach (TC_LANGS as $l) {
			foreach ($defaults['en'] as $k => $unused) {
				$v = (isset($in[$l][$k]) && is_string($in[$l][$k])) ? trim($in[$l][$k]) : '';
				$def = isset($defaults[$l][$k]) ? $defaults[$l][$k] : '';
				if ($v !== '' && $v !== $def) {
					$out[$l][$k] = wp_kses_post($v);
				}
			}
		}
		update_option('terra_texts', $out);
		$notice = '<div class="notice notice-success"><p>Saved.</p></div>';
	}
	$ov = get_option('terra_texts', array());
	if (!is_array($ov)) {
		$ov = array();
	}
	$names = tc_lang_names();
	echo '<div class="wrap"><h1>Terra Capital - Texts</h1>' . $notice;
	echo '<p>Every text on the website, in the four languages. Change any text and save. To go back to the original text, empty the box and save. In the WhatsApp message text, <code>%s</code> is replaced by the project name.</p>';
	echo '<form method="post">';
	wp_nonce_field('tc_texts_save');
	foreach ($defaults['en'] as $k => $unused) {
		echo '<fieldset style="border:1px solid #ccd0d4;background:#fff;padding:10px 14px;margin:0 0 12px"><legend><code>' . esc_html($k) . '</code></legend>';
		foreach (TC_LANGS as $l) {
			$val = isset($ov[$l][$k]) ? $ov[$l][$k] : (isset($defaults[$l][$k]) ? $defaults[$l][$k] : '');
			$dir = ($l === 'ar') ? 'rtl' : 'ltr';
			echo '<p style="margin:6px 0"><label><strong>' . esc_html($names[$l]) . '</strong><br><textarea dir="' . esc_attr($dir) . '" class="widefat" rows="2" name="tx[' . esc_attr($l) . '][' . esc_attr($k) . ']">' . esc_textarea($val) . '</textarea></label></p>';
		}
		echo '</fieldset>';
	}
	echo '<p class="submit"><input type="submit" name="tc_save_texts" class="button button-primary" value="Save texts"></p>';
	echo '</form></div>';
}
