<?php
if (!defined('ABSPATH')) exit;

function tc_register_cpt() {
	register_post_type('terra_project', array(
		'labels' => array(
			'name'          => 'Projects',
			'singular_name' => 'Project',
			'menu_name'     => 'Projects',
			'all_items'     => 'All Projects',
			'add_new'       => 'Add New Project',
			'add_new_item'  => 'Add New Project',
			'edit_item'     => 'Edit Project',
			'view_item'     => 'View Project',
		),
		'public'       => true,
		'has_archive'  => false,
		'menu_icon'    => 'dashicons-building',
		'menu_position' => 5,
		'supports'     => array('title', 'thumbnail', 'page-attributes'),
		'rewrite'      => array('slug' => 'project', 'with_front' => false),
	));
}
add_action('init', 'tc_register_cpt');

function tc_project_types() {
	return array('compound', 'apartment', 'villa', 'tourist', 'admin', 'commercial', 'land', 'other');
}

function tc_project_statuses() {
	return array('offplan', 'building', 'ready', 'resale', 'available', 'sold');
}

/* ---------- Admin: project details box ---------- */

add_action('add_meta_boxes', function () {
	add_meta_box('tc_project_box', 'Project details (4 languages)', 'tc_project_box_html', 'terra_project', 'normal', 'high');
});

add_action('admin_enqueue_scripts', function ($hook) {
	if ($hook !== 'post.php' && $hook !== 'post-new.php') {
		return;
	}
	$screen = get_current_screen();
	if ($screen && $screen->post_type === 'terra_project') {
		wp_enqueue_media();
	}
});

function tc_project_box_html($post) {
	wp_enqueue_media();
	wp_nonce_field('tc_project_save', 'tc_project_nonce');
	$meta = function ($key) use ($post) {
		return (string) get_post_meta($post->ID, $key, true);
	};
	$labels = array(
		'ar' => 'العربية (Arabic)',
		'en' => 'English',
		'de' => 'Deutsch (German)',
		'ru' => 'Русский (Russian)',
	);
	echo '<p>Fill the fields for each language. If a language is left empty, the English text is shown instead.</p>';
	foreach ($labels as $l => $label) {
		$dir = ($l === 'ar') ? 'rtl' : 'ltr';
		echo '<fieldset style="border:1px solid #ccd0d4;padding:10px 14px;margin:0 0 14px"><legend><strong>' . esc_html($label) . '</strong></legend>';
		echo '<p style="margin:6px 0"><label>Project name<br><input type="text" dir="' . esc_attr($dir) . '" class="widefat" name="tc_p[name_' . esc_attr($l) . ']" value="' . esc_attr($meta('name_' . $l)) . '"></label></p>';
		echo '<p style="margin:6px 0"><label>Location (e.g. Hurghada, New Cairo)<br><input type="text" dir="' . esc_attr($dir) . '" class="widefat" name="tc_p[place_' . esc_attr($l) . ']" value="' . esc_attr($meta('place_' . $l)) . '"></label></p>';
		echo '<p style="margin:6px 0"><label>Description<br><textarea dir="' . esc_attr($dir) . '" class="widefat" rows="4" name="tc_p[desc_' . esc_attr($l) . ']">' . esc_textarea($meta('desc_' . $l)) . '</textarea></label></p>';
		echo '</fieldset>';
	}

	$type = $meta('type');
	$status = $meta('status');
	echo '<p><label><strong>Type</strong> <select name="tc_p[type]">';
	foreach (tc_project_types() as $t) {
		echo '<option value="' . esc_attr($t) . '"' . selected($type, $t, false) . '>' . esc_html(tc('types.' . $t, 'en')) . '</option>';
	}
	echo '</select></label> &nbsp; <label><strong>Status</strong> <select name="tc_p[status]">';
	foreach (tc_project_statuses() as $s) {
		echo '<option value="' . esc_attr($s) . '"' . selected($status, $s, false) . '>' . esc_html(tc('status.' . $s, 'en')) . '</option>';
	}
	echo '</select></label></p>';
	echo '<p><label><strong>Price</strong> (shown exactly as typed, e.g. 3,500,000 EGP; leave empty to show "Price on request")<br><input type="text" class="widefat" name="tc_p[price]" value="' . esc_attr($meta('price')) . '"></label></p>';

	echo '<p><label><strong>Map location</strong> (paste a Google Maps link, or coordinates such as 27.2579,33.8116; leave empty to hide the "View on map" button)<br><input type="text" dir="ltr" class="widefat" name="tc_p[map]" value="' . esc_attr($meta('map')) . '"></label></p>';

	echo '<p><label><strong>Videos</strong> (YouTube, Vimeo or direct .mp4 links, one per line, up to 3. Videos appear next to the project images.)<br><textarea id="tc-videos" dir="ltr" class="widefat" rows="3" name="tc_p[videos]" placeholder="https://www.youtube.com/watch?v=...">' . esc_textarea($meta('videos')) . '</textarea></label><button type="button" class="button" id="tc-vid-btn">Select a video from the Media Library</button> <span class="description">(uploaded MP4 files should be small, under about 30 MB; YouTube is better for long videos)</span></p>';

	echo '<h3 style="margin:22px 0 6px">Project FAQ (questions and answers, 4 languages)</h3>';
	tc_faq_editor('tc_faq', tc_faq_project_all($post->ID));

	$gallery = $meta('gallery');
	echo '<p><strong>Gallery images</strong> (the main image is the "Featured image" box on the right)</p>';
	echo '<input type="hidden" id="tc-gal" name="tc_p[gallery]" value="' . esc_attr($gallery) . '">';
	echo '<div id="tc-gal-prev">';
	foreach (tc_project_gallery($post->ID) as $att) {
		$src = wp_get_attachment_image_url($att, 'thumbnail');
		if ($src) {
			echo '<img src="' . esc_url($src) . '" alt="" style="width:80px;height:80px;object-fit:cover;margin:4px;border-radius:4px">';
		}
	}
	echo '</div>';
	echo '<p><button type="button" class="button" id="tc-gal-btn">Select / change gallery images</button> <button type="button" class="button" id="tc-gal-clear">Clear gallery</button></p>';
	?>
	<script>
	(function () {
		var frame;
		function ids() {
			var inp = document.getElementById('tc-gal');
			return (inp && inp.value) ? inp.value.split(',').filter(Boolean) : [];
		}
		function thumb(a) {
			var im = document.createElement('img');
			im.src = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
			im.style.cssText = 'width:80px;height:80px;object-fit:cover;margin:4px;border-radius:4px';
			return im;
		}
		document.addEventListener('click', function (e) {
			var t = e.target;
			if (!t || !t.closest) { return; }
			var inp = document.getElementById('tc-gal'),
				box = document.getElementById('tc-gal-prev');
			if (t.closest('#tc-gal-clear')) {
				e.preventDefault();
				inp.value = '';
				box.innerHTML = '';
				return;
			}
			if (!t.closest('#tc-gal-btn')) { return; }
			e.preventDefault();
			if (typeof wp === 'undefined' || !wp.media) {
				alert('The WordPress media library did not load. Please reload this page (Ctrl+F5) and try again.');
				return;
			}
			if (!frame) {
				frame = wp.media({ title: 'Select project images', button: { text: 'Use these images' }, multiple: 'add', library: { type: 'image' } });
				frame.on('open', function () {
					var sel = frame.state().get('selection');
					sel.reset();
					ids().forEach(function (id) {
						var att = wp.media.attachment(id);
						att.fetch();
						sel.add(att);
					});
				});
				frame.on('select', function () {
					var sel = frame.state().get('selection').toJSON(), out = [];
					box.innerHTML = '';
					sel.forEach(function (a) {
						out.push(a.id);
						box.appendChild(thumb(a));
					});
					inp.value = out.join(',');
				});
			}
			frame.open();
		});
	})();
	</script>
	<script>
	(function () {
		var vframe;
		document.addEventListener('click', function (e) {
			var t = e.target;
			if (!t || !t.closest || !t.closest('#tc-vid-btn')) { return; }
			e.preventDefault();
			if (typeof wp === 'undefined' || !wp.media) {
				alert('The WordPress media library did not load. Please reload this page (Ctrl+F5) and try again.');
				return;
			}
			if (!vframe) {
				vframe = wp.media({ title: 'Select a video', button: { text: 'Use this video' }, multiple: false, library: { type: 'video' } });
				vframe.on('select', function () {
					var a = vframe.state().get('selection').first().toJSON();
					var ta = document.getElementById('tc-videos');
					var lines = ta.value.split(/\r?\n/).filter(function (x) { return x.trim() !== ''; });
					if (lines.length >= 3) { alert('Maximum 3 videos per project.'); return; }
					lines.push(a.url);
					ta.value = lines.join('\n');
				});
			}
			vframe.open();
		});
	})();
	</script>
	<?php
}

add_action('save_post_terra_project', function ($post_id) {
	if (!isset($_POST['tc_project_nonce'])) {
		return;
	}
	if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tc_project_nonce'])), 'tc_project_save')) {
		return;
	}
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}
	if (!current_user_can('edit_post', $post_id)) {
		return;
	}
	$in = (isset($_POST['tc_p']) && is_array($_POST['tc_p'])) ? wp_unslash($_POST['tc_p']) : array();
	foreach (TC_LANGS as $l) {
		$name  = isset($in['name_' . $l]) ? $in['name_' . $l] : '';
		$place = isset($in['place_' . $l]) ? $in['place_' . $l] : '';
		$desc  = isset($in['desc_' . $l]) ? $in['desc_' . $l] : '';
		update_post_meta($post_id, 'name_' . $l, sanitize_text_field($name));
		update_post_meta($post_id, 'place_' . $l, sanitize_text_field($place));
		update_post_meta($post_id, 'desc_' . $l, sanitize_textarea_field($desc));
	}
	$type = isset($in['type']) ? $in['type'] : '';
	$status = isset($in['status']) ? $in['status'] : '';
	update_post_meta($post_id, 'type', in_array($type, tc_project_types(), true) ? $type : 'apartment');
	update_post_meta($post_id, 'status', in_array($status, tc_project_statuses(), true) ? $status : 'available');
	update_post_meta($post_id, 'price', sanitize_text_field(isset($in['price']) ? $in['price'] : ''));
	$ids = array();
	if (!empty($in['gallery'])) {
		foreach (explode(',', $in['gallery']) as $part) {
			$n = absint($part);
			if ($n > 0) {
				$ids[] = $n;
			}
		}
	}
	update_post_meta($post_id, 'gallery', implode(',', $ids));
	update_post_meta($post_id, 'map', tc_map_sanitize(isset($in['map']) ? $in['map'] : ''));
	update_post_meta($post_id, 'videos', tc_video_sanitize(isset($in['videos']) ? $in['videos'] : ''));
	if (isset($_POST['tc_faq']) && is_array($_POST['tc_faq'])) {
		$faq = tc_faq_sanitize_post(wp_unslash($_POST['tc_faq']));
		foreach (TC_LANGS as $l) {
			update_post_meta($post_id, 'faq_' . $l, wp_slash(wp_json_encode($faq[$l], JSON_UNESCAPED_UNICODE)));
		}
	} else {
		foreach (TC_LANGS as $l) {
			delete_post_meta($post_id, 'faq_' . $l);
		}
	}
});

/* ---------- Front end helpers ---------- */

function tc_project_field($post_id, $base) {
	$value = (string) get_post_meta($post_id, $base . '_' . tc_lang(), true);
	if ($value === '') {
		$value = (string) get_post_meta($post_id, $base . '_en', true);
	}
	return $value;
}

function tc_project_name($post_id) {
	$name = tc_project_field($post_id, 'name');
	return $name !== '' ? $name : get_the_title($post_id);
}

function tc_project_gallery($post_id) {
	$raw = (string) get_post_meta($post_id, 'gallery', true);
	$ids = array();
	if ($raw !== '') {
		foreach (explode(',', $raw) as $part) {
			$n = absint($part);
			if ($n > 0) {
				$ids[] = $n;
			}
		}
	}
	return $ids;
}

function tc_project_type_label($post_id) {
	$t = (string) get_post_meta($post_id, 'type', true);
	return in_array($t, tc_project_types(), true) ? tc('types.' . $t) : '';
}

function tc_project_status_key($post_id) {
	$s = (string) get_post_meta($post_id, 'status', true);
	return in_array($s, tc_project_statuses(), true) ? $s : 'available';
}

function tc_project_price($post_id) {
	$p = trim((string) get_post_meta($post_id, 'price', true));
	return $p !== '' ? $p : tc('priceOnRequest');
}
