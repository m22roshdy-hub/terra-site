<?php
if (!defined('ABSPATH')) exit;

/* ================= FAQ + map location ================= */

/* ---------- Admin: repeater editor (4 languages) ---------- */

function tc_faq_row_html($name, $dir, $q, $a) {
	$h  = '<div class="tc-faq-row" style="border:1px solid #dcdcde;background:#fff;padding:10px;margin:0 0 8px">';
	$h .= '<p style="margin:0 0 6px"><input type="text" dir="' . esc_attr($dir) . '" class="widefat" name="' . esc_attr($name) . '[q][]" placeholder="Question" value="' . esc_attr($q) . '"></p>';
	$h .= '<p style="margin:0 0 6px"><textarea dir="' . esc_attr($dir) . '" class="widefat" rows="3" name="' . esc_attr($name) . '[a][]" placeholder="Answer">' . esc_textarea($a) . '</textarea></p>';
	$h .= '<p style="margin:0"><button type="button" class="button tc-faq-up" title="Move up">&uarr;</button> <button type="button" class="button tc-faq-dn" title="Move down">&darr;</button> <button type="button" class="button tc-faq-del" style="color:#b32d2e">Delete</button></p>';
	$h .= '</div>';
	return $h;
}

/**
 * $prefix: form field prefix. $data: array lang => list of array('q'=>..,'a'=>..)
 */
function tc_faq_editor($prefix, $data) {
	$labels = array(
		'ar' => 'العربية (Arabic)',
		'en' => 'English',
		'de' => 'Deutsch (German)',
		'ru' => 'Русский (Russian)',
	);
	foreach ($labels as $l => $label) {
		$dir = ($l === 'ar') ? 'rtl' : 'ltr';
		$name = $prefix . '[' . $l . ']';
		$items = (isset($data[$l]) && is_array($data[$l])) ? $data[$l] : array();
		echo '<fieldset style="border:1px solid #ccd0d4;padding:10px 14px;margin:0 0 14px"><legend><strong>' . esc_html($label) . '</strong></legend>';
		echo '<div class="tc-faq-list" data-name="' . esc_attr($name) . '" data-dir="' . esc_attr($dir) . '">';
		foreach ($items as $it) {
			echo tc_faq_row_html($name, $dir, isset($it['q']) ? $it['q'] : '', isset($it['a']) ? $it['a'] : '');
		}
		echo '</div>';
		echo '<p style="margin:8px 0 0"><button type="button" class="button button-secondary tc-faq-add">+ Add question</button></p>';
		echo '</fieldset>';
	}
	static $printed = false;
	if ($printed) {
		return;
	}
	$printed = true;
	?>
	<script>
	(function () {
		function build(list) {
			var name = list.getAttribute('data-name'), dir = list.getAttribute('data-dir');
			var row = document.createElement('div');
			row.className = 'tc-faq-row';
			row.style.cssText = 'border:1px solid #dcdcde;background:#fff;padding:10px;margin:0 0 8px';
			var p1 = document.createElement('p'); p1.style.margin = '0 0 6px';
			var q = document.createElement('input'); q.type = 'text'; q.className = 'widefat'; q.name = name + '[q][]'; q.placeholder = 'Question'; q.dir = dir;
			p1.appendChild(q);
			var p2 = document.createElement('p'); p2.style.margin = '0 0 6px';
			var a = document.createElement('textarea'); a.className = 'widefat'; a.rows = 3; a.name = name + '[a][]'; a.placeholder = 'Answer'; a.dir = dir;
			p2.appendChild(a);
			var p3 = document.createElement('p'); p3.style.margin = '0';
			p3.innerHTML = '<button type="button" class="button tc-faq-up" title="Move up">&uarr;</button> <button type="button" class="button tc-faq-dn" title="Move down">&darr;</button> <button type="button" class="button tc-faq-del" style="color:#b32d2e">Delete</button>';
			row.appendChild(p1); row.appendChild(p2); row.appendChild(p3);
			return row;
		}
		document.addEventListener('click', function (e) {
			var t = e.target;
			if (!t || !t.closest) { return; }
			var add = t.closest('.tc-faq-add');
			if (add) {
				e.preventDefault();
				var list = add.closest('fieldset').querySelector('.tc-faq-list');
				var row = build(list);
				list.appendChild(row);
				row.querySelector('input').focus();
				return;
			}
			var row2 = t.closest('.tc-faq-row');
			if (!row2) { return; }
			if (t.closest('.tc-faq-del')) {
				e.preventDefault();
				if (window.confirm('Delete this question?')) { row2.parentNode.removeChild(row2); }
			} else if (t.closest('.tc-faq-up')) {
				e.preventDefault();
				if (row2.previousElementSibling) { row2.parentNode.insertBefore(row2, row2.previousElementSibling); }
			} else if (t.closest('.tc-faq-dn')) {
				e.preventDefault();
				if (row2.nextElementSibling) { row2.parentNode.insertBefore(row2.nextElementSibling, row2); }
			}
		});
	})();
	</script>
	<?php
}

/* ---------- Sanitize / read ---------- */

function tc_faq_sanitize_post($raw) {
	$out = array();
	foreach (TC_LANGS as $l) {
		$list = array();
		$qs = (isset($raw[$l]['q']) && is_array($raw[$l]['q'])) ? array_values($raw[$l]['q']) : array();
		$as = (isset($raw[$l]['a']) && is_array($raw[$l]['a'])) ? array_values($raw[$l]['a']) : array();
		foreach ($qs as $i => $q) {
			$q = sanitize_text_field(is_string($q) ? $q : '');
			$a = sanitize_textarea_field((isset($as[$i]) && is_string($as[$i])) ? $as[$i] : '');
			if ($q === '' || $a === '') {
				continue;
			}
			$list[] = array('q' => $q, 'a' => $a);
			if (count($list) >= 40) {
				break;
			}
		}
		$out[$l] = $list;
	}
	return $out;
}

function tc_faq_pick($by_lang) {
	$l = tc_lang();
	if (!empty($by_lang[$l])) {
		return $by_lang[$l];
	}
	return !empty($by_lang['en']) ? $by_lang['en'] : array();
}

function tc_faq_project_all($post_id) {
	$out = array();
	foreach (TC_LANGS as $l) {
		$raw = (string) get_post_meta($post_id, 'faq_' . $l, true);
		$arr = $raw !== '' ? json_decode($raw, true) : array();
		$out[$l] = is_array($arr) ? $arr : array();
	}
	return $out;
}

function tc_faq_general_all() {
	$o = get_option('terra_faq', array());
	return is_array($o) ? $o : array();
}

/* ---------- Front end ---------- */

function tc_faq_render($items, $show_title = true) {
	if (empty($items)) {
		return;
	}
	echo '<section class="tc-faq">';
	if ($show_title) {
		echo '<h2 class="tc-h2">' . esc_html(tc('faqTitle')) . '</h2>';
	}
	echo '<div class="tc-faq-list">';
	$ld = array();
	foreach ($items as $it) {
		if (empty($it['q']) || empty($it['a'])) {
			continue;
		}
		echo '<details><summary>' . esc_html($it['q']) . '</summary><div class="a">' . wp_kses_post(wpautop(esc_html($it['a']))) . '</div></details>';
		$ld[] = array(
			'@type' => 'Question',
			'name' => $it['q'],
			'acceptedAnswer' => array('@type' => 'Answer', 'text' => $it['a']),
		);
	}
	echo '</div>';
	if ($ld) {
		$schema = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $ld);
		echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) . '</script>';
	}
	echo '</section>';
}

/* ---------- Map location ---------- */

function tc_map_sanitize($v) {
	$v = trim((string) $v);
	if ($v === '') {
		return '';
	}
	if (preg_match('/^(-?\d{1,3}(?:\.\d+)?)\s*[,;\s]\s*(-?\d{1,3}(?:\.\d+)?)$/', $v, $m)) {
		$lat = (float) $m[1];
		$lng = (float) $m[2];
		if (abs($lat) <= 90 && abs($lng) <= 180) {
			return $m[1] . ',' . $m[2];
		}
		return '';
	}
	$u = esc_url_raw($v, array('https'));
	return $u;
}

function tc_project_map_url($post_id) {
	$v = trim((string) get_post_meta($post_id, 'map', true));
	if ($v === '') {
		return '';
	}
	if (preg_match('/^-?\d{1,3}(?:\.\d+)?,-?\d{1,3}(?:\.\d+)?$/', $v)) {
		return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($v);
	}
	return esc_url_raw($v, array('https'));
}

/* ---------- General FAQ admin page ---------- */

add_action('admin_menu', function () {
	add_submenu_page('terra-settings', 'FAQ', 'FAQ', 'manage_options', 'terra-faq', 'tc_page_faq');
}, 20);

function tc_page_faq() {
	if (!current_user_can('manage_options')) {
		return;
	}
	$notice = '';
	if (isset($_POST['tc_save_faq']) && check_admin_referer('tc_faq_save')) {
		$raw = (isset($_POST['tc_gfaq']) && is_array($_POST['tc_gfaq'])) ? wp_unslash($_POST['tc_gfaq']) : array();
		update_option('terra_faq', tc_faq_sanitize_post($raw));
		$notice = '<div class="notice notice-success"><p>Saved.</p></div>';
	}
	echo '<div class="wrap"><h1>Terra Capital - General FAQ</h1>' . $notice;
	echo '<p>Frequently asked questions for the whole website (shown on the FAQ page, which is added to the menu automatically). Project-specific questions are added inside each project. A question needs both a question and an answer to be shown. If a language is empty, the English questions are shown instead. If everything is empty, the section is hidden.</p>';
	echo '<form method="post">';
	wp_nonce_field('tc_faq_save');
	tc_faq_editor('tc_gfaq', tc_faq_general_all());
	echo '<p class="submit"><input type="submit" name="tc_save_faq" class="button button-primary" value="Save FAQ"></p>';
	echo '</form></div>';
}
