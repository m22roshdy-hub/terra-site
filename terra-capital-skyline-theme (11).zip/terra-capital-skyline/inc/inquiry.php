<?php
if (!defined('ABSPATH')) exit;

/* ================= Email inquiry form ================= */

add_action('init', function () {
	register_post_type('terra_inquiry', array(
		'labels' => array(
			'name'          => 'Inquiries',
			'singular_name' => 'Inquiry',
			'menu_name'     => 'Inquiries',
			'all_items'     => 'All Inquiries',
			'edit_item'     => 'Inquiry',
			'search_items'  => 'Search inquiries',
			'not_found'     => 'No inquiries yet.',
		),
		'public'              => false,
		'publicly_queryable'  => false,
		'exclude_from_search' => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_icon'           => 'dashicons-email-alt',
		'menu_position'       => 6,
		'supports'            => array('title', 'editor'),
		'capability_type'     => 'post',
		'capabilities'        => array('create_posts' => 'do_not_allow'),
		'map_meta_cap'        => true,
		'has_archive'         => false,
		'rewrite'             => false,
	));
});

function tc_inquiry_button($project = '', $class = 'tc-btn-o') {
	$to = tc_opt('email');
	$href = is_email($to) ? 'mailto:' . $to : '#';
	echo '<a class="' . esc_attr($class) . '" href="' . esc_attr($href) . '" data-tc-inquiry data-project="' . esc_attr($project) . '">' . tc_icon_mail() . ' ' . esc_html(tc('inqBtn')) . '</a>';
}

/* ---------- Modal markup (once per page, in the footer) ---------- */

add_action('wp_footer', function () {
	$cur = tc_lang();
	?>
	<div class="tc-inq" id="tc-inq" role="dialog" aria-modal="true" aria-labelledby="tc-inq-title" data-err="<?php echo esc_attr(tc('fErr')); ?>" hidden>
		<div class="tc-inq-box">
			<button type="button" class="tc-inq-x" data-tc-inq-close aria-label="<?php echo esc_attr(tc('fClose')); ?>">&times;</button>
			<h2 class="tc-inq-h" id="tc-inq-title"><?php echo esc_html(tc('inqTitle')); ?></h2>
			<p class="tc-muted tc-inq-intro"><?php echo esc_html(tc('inqIntro')); ?></p>
			<p class="tc-inq-proj" hidden><b><?php echo esc_html(tc('inqProject')); ?>:</b> <span></span></p>
			<form class="tc-inq-form" method="post" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
				<input type="hidden" name="action" value="tc_inquiry">
				<input type="hidden" name="lang" value="<?php echo esc_attr($cur); ?>">
				<input type="hidden" name="project" value="">
				<input type="hidden" name="el" value="0">
				<div class="tc-inq-hp" aria-hidden="true"><label>Website<input type="text" name="tc_hp_site" tabindex="-1" autocomplete="off"></label></div>
				<div class="tc-inq-grid">
					<label><span><?php echo esc_html(tc('fName')); ?></span><input type="text" name="name" required maxlength="120" autocomplete="name"></label>
					<label><span><?php echo esc_html(tc('fEmail')); ?></span><input type="email" name="email" dir="ltr" required maxlength="150" autocomplete="email"></label>
					<label><span><?php echo esc_html(tc('fPhone')); ?></span><input type="tel" name="phone" dir="ltr" maxlength="40" autocomplete="tel"></label>
					<label><span><?php echo esc_html(tc('fLang')); ?></span>
						<select name="pref">
							<?php foreach (tc_lang_names() as $code => $label) : ?>
								<option value="<?php echo esc_attr($code); ?>"<?php selected($cur, $code); ?>><?php echo esc_html($label); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				</div>
				<label class="tc-inq-full"><span><?php echo esc_html(tc('fMsg')); ?></span><textarea name="message" rows="5" required minlength="5" maxlength="3000"></textarea></label>
				<label class="tc-inq-consent"><input type="checkbox" name="consent" value="1" required><span><?php echo esc_html(tc('fConsent')); ?></span></label>
				<p class="tc-inq-msg" role="alert" aria-live="polite" hidden></p>
				<button type="submit" class="tc-btn" data-sending="<?php echo esc_attr(tc('fSending')); ?>" data-label="<?php echo esc_attr(tc('fSend')); ?>"><?php echo esc_html(tc('fSend')); ?></button>
			</form>
		</div>
	</div>
	<?php
}, 5);

/* ---------- Handler ---------- */

add_action('wp_ajax_nopriv_tc_inquiry', 'tc_inquiry_handler');
add_action('wp_ajax_tc_inquiry', 'tc_inquiry_handler');

function tc_inquiry_handler() {
	$lang = isset($_POST['lang']) ? sanitize_key(wp_unslash($_POST['lang'])) : 'en';
	if (!in_array($lang, TC_LANGS, true)) {
		$lang = 'en';
	}
	$ok = function () use ($lang) {
		wp_send_json_success(array('message' => tc('fOk', $lang)));
	};
	$fail = function ($key, $code = 400) use ($lang) {
		wp_send_json_error(array('message' => tc($key, $lang)), $code);
	};

	// Bots: filled hidden field, or submitted faster than a person can type.
	if (!empty($_POST['tc_hp_site'])) {
		$ok();
	}
	$el = isset($_POST['el']) ? (int) $_POST['el'] : 0;
	if ($el < 1200) {
		$ok();
	}

	$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
	$rate_key = 'tc_inq_' . md5($ip . wp_salt());
	$sent_count = (int) get_transient($rate_key);
	if ($sent_count >= 5) {
		$fail('fWait', 429);
	}

	$name    = mb_substr(sanitize_text_field(wp_unslash(isset($_POST['name']) ? $_POST['name'] : '')), 0, 120);
	$email   = sanitize_email(wp_unslash(isset($_POST['email']) ? $_POST['email'] : ''));
	$phone   = mb_substr(preg_replace('/[^0-9+\-\s().]/', '', wp_unslash(isset($_POST['phone']) ? $_POST['phone'] : '')), 0, 40);
	$pref    = isset($_POST['pref']) ? sanitize_key(wp_unslash($_POST['pref'])) : $lang;
	$project = mb_substr(sanitize_text_field(wp_unslash(isset($_POST['project']) ? $_POST['project'] : '')), 0, 160);
	$message = mb_substr(sanitize_textarea_field(wp_unslash(isset($_POST['message']) ? $_POST['message'] : '')), 0, 3000);
	$consent = isset($_POST['consent']) && $_POST['consent'] === '1';

	if (!in_array($pref, TC_LANGS, true)) {
		$pref = $lang;
	}
	if ($name === '' || !is_email($email) || mb_strlen($message) < 5 || !$consent) {
		$fail('fInvalid');
	}

	$langs = tc_lang_names();
	$body  = "New inquiry from the website\n\n";
	$body .= 'Name: ' . $name . "\n";
	$body .= 'Email: ' . $email . "\n";
	$body .= 'Phone: ' . ($phone !== '' ? $phone : '-') . "\n";
	$body .= 'Reply in: ' . $langs[$pref] . ($pref === $lang ? ' (same as the site language the visitor used)' : ' (changed by the visitor; the site language was ' . $langs[$lang] . ')') . "\n";
	$body .= 'Project: ' . ($project !== '' ? $project : 'General inquiry') . "\n\n";
	$body .= "Message:\n" . $message . "\n";

	$stored = wp_insert_post(wp_slash(array(
		'post_type'    => 'terra_inquiry',
		'post_status'  => 'publish',
		'post_title'   => $name . ' - ' . ($project !== '' ? $project : 'General'),
		'post_content' => $body,
	)));

	$to = tc_opt('email');
	if (!is_email($to)) {
		$to = get_option('admin_email');
	}
	$header_name = trim(preg_replace('/[<>",;\r\n]+/', ' ', $name));
	$subject = str_replace(array("\r", "\n"), ' ', '[Terra Capital] Website inquiry' . ($project !== '' ? ' - ' . $project : '') . ' - ' . $name);
	$mailed = wp_mail($to, $subject, $body, array(
		'Content-Type: text/plain; charset=UTF-8',
		'Reply-To: ' . $header_name . ' <' . $email . '>',
	));

	if (!$mailed && (!$stored || is_wp_error($stored))) {
		$fail('fErr', 500);
	}
	set_transient($rate_key, $sent_count + 1, HOUR_IN_SECONDS);
	$ok();
}
