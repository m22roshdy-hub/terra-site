<?php if (!defined('ABSPATH')) exit; ?>
<div class="tc-svcs">
	<?php for ($i = 1; $i <= 4; $i++) : ?>
		<article class="tc-svc tc-reveal">
			<div class="n"><?php printf('%02d', $i); ?></div>
			<div>
				<h3><?php echo esc_html(tc('svc' . $i . 'T')); ?></h3>
				<p><?php echo esc_html(tc('svc' . $i . 'D')); ?></p>
			</div>
			<div class="art" aria-hidden="true"><?php echo tc_service_art($i); ?></div>
		</article>
	<?php endfor; ?>
</div>
