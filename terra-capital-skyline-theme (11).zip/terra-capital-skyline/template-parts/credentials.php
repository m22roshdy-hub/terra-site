<?php if (!defined('ABSPATH')) exit; ?>
<section class="tc-sec tc-alt">
	<h2 class="tc-h2"><?php echo esc_html(tc('credTitle')); ?></h2>
	<div class="tc-cred-grid">
		<div class="tc-plaque"><div class="lbl"><?php echo esc_html(tc('credCR')); ?></div><div class="val num" dir="ltr"><?php echo esc_html(tc_opt('cr')); ?></div></div>
		<div class="tc-plaque"><div class="lbl"><?php echo esc_html(tc('credTax')); ?></div><div class="val num" dir="ltr"><?php echo esc_html(tc_opt('tax')); ?></div></div>
		<div class="tc-plaque"><div class="lbl"><?php echo esc_html(tc('credForm')); ?></div><div class="val"><?php echo esc_html(tc('credFormV')); ?></div></div>
		<div class="tc-plaque"><div class="lbl"><?php echo esc_html(tc('credAct')); ?></div><div class="val"><?php echo esc_html(tc('credActV')); ?></div></div>
	</div>
	<p class="tc-lic"><?php echo tc_icon_check(); ?><span><?php echo esc_html(tc('credLic')); ?></span></p>
</section>
