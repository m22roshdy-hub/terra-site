<?php
if (!defined('ABSPATH')) exit;
$tc_fb = tc_opt('facebook');
?>
<section class="tc-sec tc-contact">
	<canvas class="tc-skyline" aria-hidden="true" data-cell="84" data-mouse="0"></canvas>
	<div class="tc-contact-grid tc-above">
		<div>
			<h2 class="tc-h2" style="max-width:20ch"><?php echo esc_html(tc('contactTitle')); ?></h2>
			<p class="tc-lead"><?php echo esc_html(tc('contactText')); ?></p>
			<a class="tc-cta" href="<?php echo esc_url(tc_whatsapp_url()); ?>" target="_blank" rel="noopener">
				<span class="tc-cta-t"><?php echo esc_html(tc('wa')); ?></span>
				<span class="tc-cta-c"><?php echo tc_icon_arrow(); ?></span>
			</a>
			<div class="tc-row">
				<?php tc_inquiry_button(''); ?>
				<?php if ($tc_fb !== '') : ?>
					<a class="tc-btn-o" href="<?php echo esc_url($tc_fb); ?>" target="_blank" rel="noopener"><?php echo tc_icon_facebook(); ?>Facebook</a>
				<?php endif; ?>
			</div>
			<div class="tc-details">
				<?php if (tc_opt('phone') !== '') : ?><div><b><?php echo esc_html(tc('phoneLbl')); ?></b><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', tc_opt('phone'))); ?>"><bdi dir="ltr"><?php echo esc_html(tc_opt('phone')); ?></bdi></a></div><?php endif; ?>
				<?php if (tc_opt('email') !== '') : ?><div><b><?php echo esc_html(tc('emailLbl')); ?></b><a href="mailto:<?php echo esc_attr(tc_opt('email')); ?>"><bdi dir="ltr"><?php echo esc_html(tc_opt('email')); ?></bdi></a></div><?php endif; ?>
				<?php if (tc_opt('address') !== '') : ?><div><b><?php echo esc_html(tc('addrLbl')); ?></b><bdi dir="ltr"><?php echo esc_html(tc_opt('address')); ?></bdi></div><?php endif; ?>
			</div>
		</div>
		<?php if (is_page('contact')) : ?>
			<div class="tc-contact-emblem" aria-hidden="true">
				<?php echo tc_ring_svg(); ?>
				<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo.png'); ?>" alt="">
			</div>
		<?php endif; ?>
	</div>
</section>
