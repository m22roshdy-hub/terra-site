<?php
if (!defined('ABSPATH')) exit;
get_header();
$tc_faq = tc_faq_pick(tc_faq_general_all());
?>
<main>
	<section class="tc-sec tc-faq-sec">
		<h1 class="tc-h2 tc-shine" style="max-width:900px;margin:0 auto 28px"><?php echo esc_html(tc('faqTitle')); ?></h1>
		<?php if ($tc_faq) : ?>
			<?php tc_faq_render($tc_faq, false); ?>
		<?php else : ?>
			<p class="tc-muted" style="max-width:900px;margin:0 auto"><?php echo esc_html(tc('faqEmpty')); ?></p>
		<?php endif; ?>
	</section>
	<?php get_template_part('template-parts/contact'); ?>
</main>
<?php get_footer(); ?>
