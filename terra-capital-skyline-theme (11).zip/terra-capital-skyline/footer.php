<?php if (!defined('ABSPATH')) exit; ?>
<footer class="tc-foot">
	<nav class="tc-foot-nav" aria-label="Footer">
		<?php
		$tc_fnav = array('home' => 'navHome', 'about' => 'navAbout', 'services' => 'navServices', 'projects' => 'navProjects', 'faq' => 'navFaq', 'contact' => 'navContact');
		foreach ($tc_fnav as $tc_slug => $tc_key) {
			echo '<a href="' . esc_url(tc_page_url($tc_slug)) . '">' . esc_html(tc($tc_key)) . '</a>';
		}
		?>
	</nav>
	<?php
	$tc_brand = tc('brand');
	if (tc_lang() === 'ar') {
		$tc_parts = preg_split('/(\s+)/u', $tc_brand, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
	} else {
		$tc_parts = preg_split('//u', $tc_brand, -1, PREG_SPLIT_NO_EMPTY);
	}
	if (!is_array($tc_parts)) {
		$tc_parts = array($tc_brand);
	}
	?>
	<div class="tc-foot-word" aria-hidden="true"><?php foreach ($tc_parts as $tc_k => $tc_p) { echo '<span style="--i:' . (int) $tc_k . '">' . esc_html($tc_p) . '</span>'; } ?></div>
	<div class="tc-copy">&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html(tc('brand')); ?></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
