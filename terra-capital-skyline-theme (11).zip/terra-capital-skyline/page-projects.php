<?php
if (!defined('ABSPATH')) exit;
get_header();
$tc_q = new WP_Query(array(
	'post_type'      => 'terra_project',
	'post_status'    => 'publish',
	'posts_per_page' => -1,
	'orderby'        => array('menu_order' => 'ASC', 'date' => 'DESC'),
));
$tc_n = 0;
?>
<main>
	<section class="tc-sec">
		<h1 class="tc-h2 tc-shine"><?php echo esc_html(tc('projTitle')); ?></h1>
		<p class="tc-lead"><?php echo esc_html(tc('projSub')); ?></p>
		<?php if ($tc_q->have_posts()) : ?>
			<div class="tc-pgrid">
				<?php while ($tc_q->have_posts()) : $tc_q->the_post(); ?>
					<?php
					$tc_n++;
					$tc_id = get_the_ID();
					$tc_name = tc_project_name($tc_id);
					$tc_place = tc_project_field($tc_id, 'place');
					$tc_type = tc_project_type_label($tc_id);
					?>
					<a class="tc-pcard tc-reveal" href="<?php echo esc_url(tc_with_lang(get_permalink())); ?>">
						<div class="tc-pimg">
							<i></i><i></i><i></i><i></i>
							<span class="tc-pn"><?php printf('%02d', $tc_n); ?></span>
							<?php
							if (has_post_thumbnail()) {
								echo get_the_post_thumbnail($tc_id, 'large', array('alt' => $tc_name, 'loading' => 'lazy'));
							} else {
								echo '<img class="ph" src="' . esc_url(get_template_directory_uri() . '/assets/logo.png') . '" alt="">';
							}
							?>
							<span class="tc-badge"><?php echo esc_html(tc('status.' . tc_project_status_key($tc_id))); ?></span>
						</div>
						<div class="tc-pmeta">
							<div>
								<h3><?php echo esc_html($tc_name); ?></h3>
								<?php if ($tc_place !== '') : ?><div class="sub"><?php echo esc_html($tc_place); ?></div><?php endif; ?>
								<?php if ($tc_type !== '') : ?><div class="tc-cat"><?php echo esc_html($tc_type); ?></div><?php endif; ?>
								<div class="price"><?php echo esc_html(tc('price') . ': ' . tc_project_price($tc_id)); ?></div>
							</div>
							<span class="tc-arr"><?php echo tc_icon_arrow(); ?></span>
						</div>
					</a>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		<?php else : ?>
			<p class="tc-lead" style="margin-top:40px"><?php echo esc_html(tc('noProjects')); ?></p>
		<?php endif; ?>
	</section>
	<?php get_template_part('template-parts/contact'); ?>
</main>
<?php get_footer(); ?>
